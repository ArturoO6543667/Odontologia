
package sql;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
public class conexionBD {
    Connection cn;
  Statement st;
  public Connection conexion()
  {
     try{
    
            Class.forName("com.mysql.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/odontologia","root" , "");
            st = cn.createStatement();
           // JOptionPane.showMessageDialog(null ,"conectado");
               
        }catch(Exception e){
            JOptionPane.showMessageDialog(null ,"No estas conectado");
        }
     return cn;
  }

    public PreparedStatement prepareStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
