
package odontologia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import sql.conexionBD;

public class Datos_Personales extends javax.swing.JFrame {

    public Datos_Personales() {
        initComponents();
    }
    conexionBD cna= new conexionBD();
    PreparedStatement ps = null;
    ResultSet rs=null;   
    Connection cn = cna.conexion();
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        txtapellido = new javax.swing.JTextField();
        btocancelar = new javax.swing.JButton();
        btoguardar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txtci = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtocupacion = new javax.swing.JTextField();
        fecha = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_datosPersonales = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        btomodificar = new javax.swing.JButton();
        btoactualizar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setText("Nombre:");

        jLabel2.setText("Apellido:");

        jLabel3.setText("Fecha de nacimiento:");

        btocancelar.setText("Cancelar");
        btocancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btocancelarActionPerformed(evt);
            }
        });

        btoguardar.setText("Guardar");
        btoguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btoguardarActionPerformed(evt);
            }
        });

        jLabel8.setText("C.I:");

        txtci.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtciActionPerformed(evt);
            }
        });

        jLabel9.setText("Ocupacion:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(btocancelar)
                .addGap(18, 18, 18)
                .addComponent(btoguardar)
                .addGap(0, 72, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtapellido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                            .addComponent(txtnombre, javax.swing.GroupLayout.Alignment.LEADING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtocupacion, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                            .addComponent(txtci)
                            .addComponent(fecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtapellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtci, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtocupacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btocancelar)
                    .addComponent(btoguardar))
                .addGap(23, 23, 23))
        );

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("REGISTRO DE DATOS PERSONALES");

        tabla_datosPersonales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tabla_datosPersonales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabla_datosPersonalesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla_datosPersonales);

        jLabel5.setText("Buscar:");

        btomodificar.setText("Modificar");
        btomodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btomodificarActionPerformed(evt);
            }
        });

        btoactualizar.setText("Actualizar");
        btoactualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btoactualizarActionPerformed(evt);
            }
        });

        jLabel6.setText("Lista de pacientes ya registrados");

        jLabel7.setText("Formulario de registro:");

        jButton5.setText("Atrás");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(214, 214, 214)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(244, 244, 244))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btomodificar)
                        .addGap(44, 44, 44)
                        .addComponent(btoactualizar)
                        .addGap(111, 111, 111))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField4))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btoactualizar)
                            .addComponent(btomodificar)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jButton5)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtciActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtciActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtciActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
      REGISTRAR_PACIENT R = new REGISTRAR_PACIENT();
        R.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void btoactualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btoactualizarActionPerformed
     DefaultTableModel model = new DefaultTableModel();  
        try {                    
            tabla_datosPersonales.setModel(model); 
            String sql = "SELECT nombre, apellido, fecha_nacimiento, ci,ocupacion "
                       + "FROM paciente ";
                      
            System.out.println(sql);
            ps = cn.prepareStatement(sql);
            rs = ps.executeQuery();         
            ResultSetMetaData rsMd = rs.getMetaData();
            int cantidadColumnas = rsMd.getColumnCount();          
            model.addColumn("Nombre");
            model.addColumn("Apellido");
            model.addColumn("Fecha de nacimiento");
            model.addColumn("C.I");
            model.addColumn("Ocupacion");
            
            while(rs.next())
            {
                Object[] filas = new Object[cantidadColumnas];
                for(int i=0;i<cantidadColumnas;i++)
                {
                    filas[i]=rs.getObject(i+1);
                }
                model.addRow(filas);
            }
        }
        catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Hubo un error :( vuelva a intentarlo");
        }           
    }//GEN-LAST:event_btoactualizarActionPerformed
    public void mostrar_paciente()
    {
         DefaultTableModel model = new DefaultTableModel();  
        try {                    
            tabla_datosPersonales.setModel(model); 
            String sql = "SELECT nombre, apellido, fecha_nacimiento, ci,ocupacion "
                       + "FROM paciente ";
                      
            System.out.println(sql);
            ps = cn.prepareStatement(sql);
            rs = ps.executeQuery();         
            ResultSetMetaData rsMd = rs.getMetaData();
            int cantidadColumnas = rsMd.getColumnCount();          
            model.addColumn("Nombre");
            model.addColumn("Apellido");
            model.addColumn("Fecha de nacimiento");
            model.addColumn("C.I");
            model.addColumn("Ocupacion");
            
            while(rs.next())
            {
                Object[] filas = new Object[cantidadColumnas];
                for(int i=0;i<cantidadColumnas;i++)
                {
                    filas[i]=rs.getObject(i+1);
                }
                model.addRow(filas);
            }
        }
        catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Hubo un error :( vuelva a intentarlo");
        }       
    }
    public void limpiar_paciente()
    {
        txtnombre.setText("");
        txtapellido.setText("");
        fecha.setDate(null);
        txtci.setText("");
        txtocupacion.setText("");
        
        
    }
    private void btomodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btomodificarActionPerformed
        try {            
         Date date = fecha.getDate();
         long d   = date.getTime();
         java.sql.Date fechita  = new java.sql.Date(d);        
         ps = cn.prepareStatement("UPDATE paciente SET nombre='"+ txtnombre.getText()+"', "
                    + "apellido='"+ txtapellido.getText()+"',fecha_nacimiento='"+ fechita+ "',"
                    + " ci='"+ txtci.getText()+"'");                  
            ps.executeUpdate();                     
             mostrar_paciente();
             limpiar_paciente();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al Modificar Medico");
             System.out.println(ex);
        }    
    }//GEN-LAST:event_btomodificarActionPerformed
 public static int id_paciente = 0;
    private void tabla_datosPersonalesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabla_datosPersonalesMouseClicked
       try{     
        int fila = tabla_datosPersonales.getSelectedRow();
        String nombre = tabla_datosPersonales.getValueAt(fila, 0).toString();  
        System.out.println(nombre);
        ps = cn.prepareStatement("SELECT id_paciente, nombre, apellido, fecha_nacimiento, ci,ocupacion "
                               + "FROM paciente "
                               + "WHERE id_paciente='"+nombre+"'");  
        rs=ps.executeQuery();
       
        while(rs.next())
        {  
            id_paciente=rs.getInt("id_paciente");
            txtnombre.setText(rs.getString("nombre"));
            txtapellido.setText(rs.getString("apellido"));
            fecha.setDate(rs.getDate("fecha_nacimiento"));
            txtci.setText(rs.getString("ci"));
            txtocupacion.setText(rs.getString("ocupacion"));
           
        }
        
    }catch(SQLException e)
    {
        JOptionPane.showMessageDialog(null, "Hubo un error :( vuelva a intentarlo");
        System.out.println(e.toString());
    }     
    }//GEN-LAST:event_tabla_datosPersonalesMouseClicked

    private void btocancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btocancelarActionPerformed
      limpiar_paciente();
    }//GEN-LAST:event_btocancelarActionPerformed

    private void btoguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btoguardarActionPerformed
     DefaultTableModel model = new DefaultTableModel();         
           
        try{   
        
            Date date = fecha.getDate();
            long d   = date.getTime();
            java.sql.Date fecha1  = new java.sql.Date(d);          
            ps = cn.prepareStatement("INSERT INTO paciente(id_paciente, "
                + "nombre,apellido,fecha_nacimiento,ci, ocupacion "
                + "VALUES(null,?,?,?,?,?)");
            ps.setString(1, txtnombre.getText());
            ps.setString(2, txtapellido.getText());
            ps.setDate(3, fecha1);
            ps.setString(4, txtci.getText());       
            ps.setString(5, txtocupacion.getText());
            ps.executeUpdate();           
       
        }catch(SQLException e)
        {
              System.out.println(e.toString());
            JOptionPane.showMessageDialog(null, "Error, revise bien sus datos ");
        }       
       
    }//GEN-LAST:event_btoguardarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Datos_Personales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Datos_Personales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Datos_Personales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Datos_Personales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Datos_Personales().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btoactualizar;
    private javax.swing.JButton btocancelar;
    private javax.swing.JButton btoguardar;
    private javax.swing.JButton btomodificar;
    private com.toedter.calendar.JDateChooser fecha;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTable tabla_datosPersonales;
    private javax.swing.JTextField txtapellido;
    private javax.swing.JTextField txtci;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtocupacion;
    // End of variables declaration//GEN-END:variables
}
